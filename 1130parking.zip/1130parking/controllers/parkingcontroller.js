const Parking=require('../models/parking')

exports.dashboard=(req,res)=>{
    const username=req.session.username
    res.render('dashboard.ejs',{username})
}
exports.parkingaddform=(req,res)=>{
    const username=req.session.username
    res.render('addform.ejs',{username,message:''})
}
exports.parkingadd=(req,res)=>{
    try{
    const username=req.session.username
    const {vnumber,vtype}=req.body
   const record=Parking({vnumber:vnumber,vtype:vtype})
       record.save()
       //console.log(record)
       res.render('addform.ejs',{username,message:'Successfully new entery added'})
    }catch(error){
        console.log(error.message)
    }
}
exports.parkingselection= async (req,res)=>{
    try{
    const username=req.session.username
     const record=await Parking.find().sort({status:1})
    res.render('out.ejs',{username,record})
    }catch(error){
        console.log(error.message)
    }
}
exports.update= async (req,res)=>{
    try{
    const id=req.params.id
      let outtime=new Date()
   const record=await Parking.findById(id)
    let totalTimeSpend=((outtime-record.vin)/(1000*60*60))
    //console.log(totalTimeSpend) 
       let amount=null
    if(record.vtype=='2w'){
          amount=totalTimeSpend*30
    }
    else if(record.vtype=='3w'){
        amount=totalTimeSpend*50
    }
    else if(record.vtype=='4w'){
        amount=totalTimeSpend*80
    }
    else if(record.vtype=='lv'){
        amount=totalTimeSpend*120
    }
    else if(record.vtype=='hv'){
        amount=totalTimeSpend*150
    }
   else{
    amount=totalTimeSpend*100
   }
   if(amount<=30){
       amount=15
   }
  await Parking.findByIdAndUpdate(id,{vout:outtime,amount: Math.round(amount),status:'OUT',totaltime: Math.round(totalTimeSpend)})
     res.redirect('/out')
}catch(error){
    console.log(error.message)
}
}
exports.print= async (req,res)=>{
    try{
    const id=req.params.id
     const record=await Parking.findById(id)
    res.render('print.ejs',{record})
    }catch(error){
        console.log(error.message)
    }
}