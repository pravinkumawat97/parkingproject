const Reg=require('../models/reg')

exports.loginpage=(req,res)=>{    
        res.render('login.ejs',{message:''})    
}
exports.logincheck= async (req,res)=>{
    try{
    const {us,pass}=req.body
    const usercheck=await Reg.findOne({username:us})
    if(usercheck!==null){
        if(usercheck.password==pass){
            req.session.isAuth=true
            req.session.username=us
        res.redirect('/parkingdashboard')
        }else{
            res.render('login.ejs',{message:'Wrong Password'}) 
        }
    }else{
        res.render('login.ejs',{message:'Wrong username'}) 
    }
}catch(error){
    console.log(error.message)
}
}
exports.logout=(req,res)=>{
    req.session.destroy()
    res.redirect('/')
}