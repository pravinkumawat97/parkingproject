const express=require('express')
const app=express()
require('dotenv').config()
app.use(express.urlencoded({extended:false}))
const parkingRouter=require('./routers/parking')
const mongoose=require('mongoose')
const connect=mongoose.connect(`${process.env.DB_URL}/${process.env.DB_NAME}`).then(()=>{console.log('project is connected to DB')})
const session=require('express-session')

app.use(session({
    secret:process.env.KEY,
    resave:false,
    saveUninitialized:false,
    cookie:{maxAge:1000*60*60*24}
}))
app.use(parkingRouter)
app.use(express.static('public'))
app.set('view engine','ejs')
app.listen(process.env.PORT,()=>{console.log(`server is running on PORT ${process.env.PORT}`)})