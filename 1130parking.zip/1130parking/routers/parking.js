const router=require('express').Router()
const regc=require('../controllers/regcontroller')
const parkingc=require('../controllers/parkingcontroller')
const handlelogin=require('../helpers/sessioncheck')

router.get('/',regc.loginpage)
router.post('/',regc.logincheck)
router.get('/parkingdashboard',handlelogin,parkingc.dashboard)
router.get('/logout',handlelogin,regc.logout)
router.get('/addform',handlelogin,parkingc.parkingaddform)
router.post('/addform',parkingc.parkingadd)
router.get('/out',handlelogin,parkingc.parkingselection)
router.get('/update/:id',handlelogin,parkingc.update)
router.get('/print/:id',handlelogin,parkingc.print)

 module.exports=router